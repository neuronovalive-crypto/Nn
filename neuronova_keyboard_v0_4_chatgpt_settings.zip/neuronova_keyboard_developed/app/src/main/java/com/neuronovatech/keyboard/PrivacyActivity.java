package com.neuronovatech.keyboard;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PrivacyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Privacy Policy Draft");
        title.setTextSize(24);
        root.addView(title);

        TextView body = new TextView(this);
        body.setText("NeuroNova Keyboard is developed by NeuroNova Tech.\n\n" +
                "Normal typing: NeuroNova Keyboard does not send normal keystrokes to any server.\n\n" +
                "AI Button: When the user taps or long-presses the AI button, the selected spoken or typed text is sent to OpenAI/ChatGPT engine for rewriting/completion.\n\n" +
                "Microphone: Microphone permission is used only when the user taps the AI button for speech input.\n\n" +
                "API key: This MVP can store an OpenAI API key in private app preferences on the device and can also use a default build key set through GitHub Secrets/local Gradle property. For a public production release, NeuroNova Tech should use secure server-side key management.\n\n" +
                "Keyboard personalization: Keyboard size, colour theme, layout choice, sound, vibration, and background image preference are stored only on the user device.\n\n" +
                "Data retention: This MVP does not store AI prompts or outputs after insertion.\n\n" +
                "Thanks to developers: M HOSSAIN and R ISLAM RAHI.\n\n" +
                "Contact: NeuroNova Tech");
        body.setTextSize(16);
        body.setPadding(0, dp(16), 0, 0);
        root.addView(body);

        setContentView(scroll);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
