package com.neuronovatech.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(22);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("neuronova_logo", "drawable", getPackageName()));
        logo.setAdjustViewBounds(true);
        logo.setMaxHeight(dp(150));
        root.addView(logo, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(125)));

        TextView title = new TextView(this);
        title.setText("NeuroNova Keyboard");
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(18), 0, dp(6));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Bangla + English keyboard with ChatGPT/OpenAI AI sentence completion.\nDeveloped by NeuroNova Tech.");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(14));
        root.addView(subtitle);

        root.addView(actionButton("1. Enable NeuroNova Keyboard", v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))));
        root.addView(actionButton("2. Choose Keyboard", v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        }));
        root.addView(actionButton("3. AI Settings / OpenAI API Key", v -> startActivity(new Intent(this, SettingsActivity.class))));
        root.addView(actionButton("Privacy Policy", v -> startActivity(new Intent(this, PrivacyActivity.class))));

        TextView features = new TextView(this);
        features.setText("Included now:\n\n• English QWERTY layout\n• Bangla fixed layout\n• Avro-style Bangla phonetic mode: ami → আমি\n• Symbols and emoji pages\n• AI button using ChatGPT/OpenAI engine\n• Tap AI: speak unfinished sentence\n• Long press AI: rewrite typed sentence before cursor\n• Keyboard size, colour, layout, sound and background image settings\n• Privacy note: normal typing stays on device");
        features.setTextSize(15);
        features.setPadding(0, dp(20), 0, dp(10));
        root.addView(features);

        TextView footer = new TextView(this);
        footer.setText("Version 0.4.0 — NeuroNova Tech");
        footer.setTextSize(13);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(14), 0, dp(22));
        root.addView(footer);

        setContentView(scroll);
    }

    private Button actionButton(String text, android.view.View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(16);
        button.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        lp.setMargins(0, dp(10), 0, 0);
        button.setLayoutParams(lp);
        return button;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
