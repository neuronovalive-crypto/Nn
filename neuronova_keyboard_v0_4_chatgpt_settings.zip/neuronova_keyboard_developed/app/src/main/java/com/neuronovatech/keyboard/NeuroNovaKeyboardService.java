package com.neuronovatech.keyboard;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.inputmethodservice.InputMethodService;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.List;

public class NeuroNovaKeyboardService extends InputMethodService {
    private enum Mode { ENGLISH, BANGLA_FIXED, BANGLA_PHONETIC, SYMBOLS, EMOJI }

    private Mode mode = Mode.ENGLISH;
    private Mode previousTextMode = Mode.ENGLISH;
    private boolean capsMode = false;
    private LinearLayout keyboardRoot;
    private TextView statusView;
    private TextView suggestionView;
    private SpeechRecognizer speechRecognizer;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final StringBuilder phoneticRaw = new StringBuilder();
    private int phoneticCommittedLength = 0;

    private final String[][] englishRows = {
            {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"},
            {"a", "s", "d", "f", "g", "h", "j", "k", "l"},
            {"⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"}
    };

    private final String[][] phoneticRows = {
            {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"},
            {"a", "s", "d", "f", "g", "h", "j", "k", "l"},
            {"⇧", "z", "x", "c", "v", "b", "n", "m", "⌫"}
    };

    private final String[][] banglaRows = {
            {"অ", "আ", "ই", "ঈ", "উ", "ঊ", "এ", "ঐ", "ও", "ঔ"},
            {"ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"},
            {"ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"},
            {"প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"},
            {"স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ", "⌫"}
    };

    private final String[][] symbolRows = {
            {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"},
            {"@", "#", "৳", "_", "&", "-", "+", "(", ")", "/"},
            {"*", "\"", "'", ":", ";", "!", "?", ",", ".", "⌫"}
    };

    private final String[][] emojiRows = {
            {"😀", "😂", "😊", "😍", "🥰", "😎", "😢", "😡"},
            {"👍", "🙏", "👏", "🔥", "❤️", "💙", "✅", "⭐"},
            {"🎉", "📌", "📷", "🎬", "💡", "🚀", "☕", "⌫"}
    };

    @Override
    public View onCreateInputView() {
        mode = modeFromDefaultSetting();
        previousTextMode = mode;
        keyboardRoot = new LinearLayout(this);
        keyboardRoot.setOrientation(LinearLayout.VERTICAL);
        keyboardRoot.setGravity(Gravity.CENTER);
        keyboardRoot.setPadding(dp(6), dp(5), dp(6), dp(5));
        applyKeyboardBackground();
        rebuildKeyboard();
        return keyboardRoot;
    }

    @Override
    public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        clearPhoneticBuffer();
        setStatus(defaultStatus());
    }

    @Override
    public void onDestroy() {
        destroySpeechRecognizer();
        super.onDestroy();
    }

    private void rebuildKeyboard() {
        if (keyboardRoot == null) return;
        applyKeyboardBackground();
        keyboardRoot.removeAllViews();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        keyboardRoot.addView(top, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(32)));

        statusView = new TextView(this);
        statusView.setText(defaultStatus());
        statusView.setTextColor(0xFFFFFFFF);
        statusView.setTextSize(12);
        statusView.setGravity(Gravity.CENTER_VERTICAL);
        statusView.setSingleLine(true);
        top.addView(statusView, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1));

        Button settings = makeSmallButton("⚙");
        settings.setOnClickListener(v -> openSettings());
        top.addView(settings, new LinearLayout.LayoutParams(dp(42), dp(28)));

        suggestionView = new TextView(this);
        suggestionView.setText(suggestionText());
        suggestionView.setTextColor(0xFF001149);
        suggestionView.setTextSize(13);
        suggestionView.setGravity(Gravity.CENTER_VERTICAL);
        suggestionView.setPadding(dp(12), 0, dp(12), 0);
        suggestionView.setBackgroundResource(getResources().getIdentifier("panel_background", "drawable", getPackageName()));
        suggestionView.setOnClickListener(v -> acceptTopPhoneticSuggestion());
        int suggestionHeight = NeuroNovaPrefs.showSuggestions(this) ? dp(32) : dp(0);
        keyboardRoot.addView(suggestionView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, suggestionHeight));

        String[][] rows = currentRows();
        for (String[] row : rows) addRow(row);
        addBottomRow();
    }

    private Mode modeFromDefaultSetting() {
        String layout = NeuroNovaPrefs.getDefaultLayout(this);
        if ("Bangla Fixed".equals(layout)) return Mode.BANGLA_FIXED;
        if ("Avro Phonetic".equals(layout)) return Mode.BANGLA_PHONETIC;
        return Mode.ENGLISH;
    }

    private int rowHeight() {
        String size = NeuroNovaPrefs.getKeyboardSize(this);
        if ("Small".equals(size)) return dp(42);
        if ("Large".equals(size)) return dp(53);
        if ("Extra Large".equals(size)) return dp(60);
        return dp(47);
    }

    private int keyHeight() {
        String size = NeuroNovaPrefs.getKeyboardSize(this);
        if ("Small".equals(size)) return dp(36);
        if ("Large".equals(size)) return dp(47);
        if ("Extra Large".equals(size)) return dp(54);
        return dp(41);
    }

    private int themeBackgroundColor() {
        String theme = NeuroNovaPrefs.getTheme(this);
        if ("Dark Black".equals(theme)) return Color.rgb(18, 18, 20);
        if ("Light White".equals(theme)) return Color.rgb(238, 242, 247);
        if ("Green".equals(theme)) return Color.rgb(0, 86, 64);
        if ("Purple".equals(theme)) return Color.rgb(58, 36, 111);
        return Color.rgb(0, 17, 73);
    }

    private int themeKeyColor(boolean action, boolean ai) {
        String theme = NeuroNovaPrefs.getTheme(this);
        if (ai) return Color.rgb(0, 122, 255);
        if ("Dark Black".equals(theme)) return action ? Color.rgb(60, 60, 65) : Color.rgb(245, 245, 245);
        if ("Light White".equals(theme)) return action ? Color.rgb(210, 222, 240) : Color.WHITE;
        if ("Green".equals(theme)) return action ? Color.rgb(210, 240, 230) : Color.WHITE;
        if ("Purple".equals(theme)) return action ? Color.rgb(225, 218, 250) : Color.WHITE;
        return action ? Color.rgb(223, 233, 255) : Color.WHITE;
    }

    private int themeTextColor(boolean action, boolean ai) {
        if (ai) return Color.WHITE;
        if ("Dark Black".equals(NeuroNovaPrefs.getTheme(this)) && !action) return Color.rgb(5, 9, 20);
        return Color.rgb(0, 17, 73);
    }

    private void styleButton(Button button, String key) {
        boolean ai = key.equals("AI");
        boolean action = isActionKey(key);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(themeKeyColor(action, ai));
        bg.setCornerRadius(dp(ai ? 15 : 10));
        bg.setStroke(dp(1), ai ? Color.rgb(160, 210, 255) : Color.argb(80, 0, 17, 73));
        button.setBackground(bg);
        button.setTextColor(themeTextColor(action, ai));
    }

    private void applyKeyboardBackground() {
        if (keyboardRoot == null) return;
        String uriString = NeuroNovaPrefs.getBackgroundImageUri(this);
        if (uriString != null && !uriString.isEmpty()) {
            try {
                InputStream is = getContentResolver().openInputStream(Uri.parse(uriString));
                Bitmap bitmap = BitmapFactory.decodeStream(is);
                if (is != null) is.close();
                if (bitmap != null) {
                    BitmapDrawable drawable = new BitmapDrawable(getResources(), bitmap);
                    drawable.setAlpha(205);
                    keyboardRoot.setBackground(drawable);
                    return;
                }
            } catch (Exception ignored) { }
        }
        keyboardRoot.setBackgroundColor(themeBackgroundColor());
    }

    private String[][] currentRows() {
        switch (mode) {
            case BANGLA_FIXED: return banglaRows;
            case BANGLA_PHONETIC: return phoneticRows;
            case SYMBOLS: return symbolRows;
            case EMOJI: return emojiRows;
            case ENGLISH:
            default: return englishRows;
        }
    }

    private String defaultStatus() {
        switch (mode) {
            case BANGLA_FIXED: return "NeuroNova Bangla | AI tap: speak, long press: rewrite";
            case BANGLA_PHONETIC: return "NeuroNova Avro-style Phonetic | ami → আমি";
            case SYMBOLS: return "NeuroNova Symbols";
            case EMOJI: return "NeuroNova Emoji";
            case ENGLISH:
            default: return "NeuroNova English | AI tap: speak, long press: rewrite";
        }
    }

    private String suggestionText() {
        if (mode == Mode.BANGLA_PHONETIC && phoneticRaw.length() > 0) {
            List<String> suggestions = BanglaPhonetic.suggestions(phoneticRaw.toString());
            if (suggestions.size() > 0) return "Tap suggestion: " + joinSuggestions(suggestions);
            return "Avro-style: " + phoneticRaw + "  →  " + BanglaPhonetic.transliterate(phoneticRaw.toString());
        }
        if (mode == Mode.BANGLA_PHONETIC) return "Avro-style examples: ami → আমি | bangladesh → বাংলাদেশ | college → কলেজ";
        return "Privacy: only AI Button text is sent to OpenAI. Normal typing stays on device.";
    }

    private String joinSuggestions(List<String> suggestions) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < suggestions.size() && i < 4; i++) {
            if (i > 0) sb.append("   ");
            sb.append(suggestions.get(i));
        }
        return sb.toString();
    }

    private void acceptTopPhoneticSuggestion() {
        if (mode != Mode.BANGLA_PHONETIC || phoneticRaw.length() == 0) return;
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        List<String> suggestions = BanglaPhonetic.suggestions(phoneticRaw.toString());
        if (suggestions.size() == 0) return;
        if (phoneticCommittedLength > 0) ic.deleteSurroundingText(phoneticCommittedLength, 0);
        ic.commitText(suggestions.get(0), 1);
        clearPhoneticBuffer();
    }

    private void addBottomRow() {
        if (mode == Mode.SYMBOLS) {
            addRow(new String[]{modeButtonForPrevious(), "😊", "AI", "Space", "⌫", "⏎"});
        } else if (mode == Mode.EMOJI) {
            addRow(new String[]{modeButtonForPrevious(), "123", "AI", "Space", "⌫", "⏎"});
        } else if (mode == Mode.BANGLA_PHONETIC) {
            addRow(new String[]{"EN", "কখ", "123", "AI", "Space", ".", "⏎"});
        } else if (mode == Mode.BANGLA_FIXED) {
            addRow(new String[]{"EN", "AVRO", "123", "AI", "Space", "্", "⏎"});
        } else {
            addRow(new String[]{"BN", "AVRO", "123", "AI", "Space", ".", "⏎"});
        }
    }

    private String modeButtonForPrevious() {
        if (previousTextMode == Mode.BANGLA_FIXED) return "কখ";
        if (previousTextMode == Mode.BANGLA_PHONETIC) return "AVRO";
        return "ABC";
    }

    private void addRow(String[] keys) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        keyboardRoot.addView(row, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, rowHeight()));

        for (String key : keys) {
            Button button = new Button(this);
            String label = displayLabel(key);
            button.setText(label);
            button.setAllCaps(false);
            button.setTextSize(key.equals("Space") ? 13 : (key.codePointCount(0, key.length()) > 1 ? 15 : 18));
            button.setGravity(Gravity.CENTER);
            button.setPadding(0, 0, 0, 0);
            styleButton(button, key);

            button.setOnClickListener(v -> {
                if (NeuroNovaPrefs.isVibrationEnabled(this)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                handleKey(key);
            });
            button.setOnLongClickListener(v -> handleLongPress(key));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, keyHeight(), weightForKey(key));
            lp.setMargins(dp(2), dp(3), dp(2), dp(3));
            row.addView(button, lp);
        }
    }

    private Button makeSmallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setPadding(0, 0, 0, 0);
        styleButton(b, "ABC");
        return b;
    }

    private String displayLabel(String key) {
        if (key.equals("Space")) return "Space";
        if (key.equals("AI")) return "AI";
        if (capsMode && key.length() == 1 && key.matches("[a-z]")) return key.toUpperCase(Locale.US);
        return key;
    }

    private float weightForKey(String key) {
        if (key.equals("Space")) return 3.4f;
        if (key.equals("AI")) return 1.45f;
        if (key.equals("BN") || key.equals("EN") || key.equals("ABC") || key.equals("কখ") || key.equals("PH")) return 1.25f;
        if (isActionKey(key)) return 1.15f;
        return 1f;
    }

    private boolean isActionKey(String key) {
        return key.equals("⌫") || key.equals("⏎") || key.equals("Space") || key.equals("123") || key.equals("AI")
                || key.equals("BN") || key.equals("EN") || key.equals("ABC") || key.equals("কখ") || key.equals("PH") || key.equals("AVRO")
                || key.equals("⇧") || key.equals("😊");
    }

    private boolean handleLongPress(String key) {
        if (key.equals("AI")) {
            rewriteTextBeforeCursor();
            return true;
        }
        if (key.equals("⌫")) {
            deleteWordBeforeCursor();
            return true;
        }
        if (key.equals("Space")) {
            switchToNextInputMethod(false);
            return true;
        }
        return false;
    }

    private void handleKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (key) {
            case "Space": commitSeparator(" "); break;
            case "⌫": handleBackspace(); break;
            case "⏎": commitSeparator("\n"); break;
            case "123": switchMode(Mode.SYMBOLS); break;
            case "😊": switchMode(Mode.EMOJI); break;
            case "ABC": switchMode(Mode.ENGLISH); break;
            case "কখ": switchMode(Mode.BANGLA_FIXED); break;
            case "BN": switchMode(Mode.BANGLA_FIXED); break;
            case "PH":
            case "AVRO": switchMode(Mode.BANGLA_PHONETIC); break;
            case "EN": switchMode(Mode.ENGLISH); break;
            case "⇧": capsMode = !capsMode; rebuildKeyboard(); break;
            case "AI": playAiStartSound(); startAiSpeechFlow(); break;
            default: commitNormalKey(key); break;
        }
    }

    private void switchMode(Mode newMode) {
        if (mode == Mode.ENGLISH || mode == Mode.BANGLA_FIXED || mode == Mode.BANGLA_PHONETIC) previousTextMode = mode;
        if (newMode != Mode.BANGLA_PHONETIC) clearPhoneticBuffer();
        mode = newMode;
        rebuildKeyboard();
    }

    private void commitNormalKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        if (mode == Mode.BANGLA_PHONETIC && key.length() == 1 && key.matches("[a-zA-Z0-9]")) {
            String rawKey = capsMode ? key.toUpperCase(Locale.US) : key;
            phoneticRaw.append(rawKey.toLowerCase(Locale.US));
            refreshPhoneticCommit();
            return;
        }

        clearPhoneticBuffer();
        String out = capsMode && key.length() == 1 && key.matches("[a-z]") ? key.toUpperCase(Locale.US) : key;
        ic.commitText(out, 1);
    }

    private void commitSeparator(String separator) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        clearPhoneticBuffer();
        ic.commitText(separator, 1);
    }

    private void handleBackspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (mode == Mode.BANGLA_PHONETIC && phoneticRaw.length() > 0) {
            phoneticRaw.deleteCharAt(phoneticRaw.length() - 1);
            refreshPhoneticCommit();
            return;
        }
        ic.deleteSurroundingText(1, 0);
    }

    private void refreshPhoneticCommit() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (phoneticCommittedLength > 0) ic.deleteSurroundingText(phoneticCommittedLength, 0);
        String converted = BanglaPhonetic.transliterate(phoneticRaw.toString());
        if (!converted.isEmpty()) ic.commitText(converted, 1);
        phoneticCommittedLength = converted.length();
        if (suggestionView != null) suggestionView.setText(suggestionText());
    }

    private void clearPhoneticBuffer() {
        phoneticRaw.setLength(0);
        phoneticCommittedLength = 0;
        if (suggestionView != null) suggestionView.setText(suggestionText());
    }

    private void deleteWordBeforeCursor() {
        clearPhoneticBuffer();
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence before = ic.getTextBeforeCursor(80, 0);
        if (before == null || before.length() == 0) return;
        int deleteCount = before.length();
        for (int i = before.length() - 1; i >= 0; i--) {
            char c = before.charAt(i);
            if (Character.isWhitespace(c)) {
                deleteCount = before.length() - i - 1;
                break;
            }
        }
        if (deleteCount <= 0) deleteCount = 1;
        ic.deleteSurroundingText(deleteCount, 0);
    }

    private void playAiStartSound() {
        if (!NeuroNovaPrefs.isAiSoundEnabled(this)) return;
        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, 75);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 130);
            mainHandler.postDelayed(tg::release, 180);
        } catch (Exception ignored) { }
    }

    private void playAiDoneSound() {
        if (!NeuroNovaPrefs.isAiSoundEnabled(this)) return;
        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 180);
            mainHandler.postDelayed(tg::release, 240);
        } catch (Exception ignored) { }
    }

    private void playAiErrorSound() {
        if (!NeuroNovaPrefs.isAiSoundEnabled(this)) return;
        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, 70);
            tg.startTone(ToneGenerator.TONE_PROP_NACK, 180);
            mainHandler.postDelayed(tg::release, 240);
        } catch (Exception ignored) { }
    }

    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void startAiSpeechFlow() {
        clearPhoneticBuffer();
        String apiKey = NeuroNovaPrefs.getOpenAiApiKey(this);
        if (apiKey.isEmpty()) {
            setStatus("Add OpenAI API key in ⚙ settings first");
            openSettings();
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Speech recognition is not available on this device");
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setStatus("Allow microphone permission, then tap AI again");
            Intent intent = new Intent(this, PermissionActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        }

        destroySpeechRecognizer();
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { setStatus("Listening... speak unfinished sentence"); }
            @Override public void onBeginningOfSpeech() { setStatus("Listening..."); }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { setStatus("Processing speech..."); }
            @Override public void onError(int error) { setStatus("Could not hear clearly. Tap AI again."); playAiErrorSound(); }
            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches == null || matches.isEmpty()) {
                    setStatus("No speech detected");
                    return;
                }
                String spoken = matches.get(0);
                setStatus("ChatGPT is making it complete...");
                rewriteWithOpenAI(spoken, 0);
            }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, preferredSpeechLanguage());
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your unfinished sentence");
        speechRecognizer.startListening(intent);
    }

    private String preferredSpeechLanguage() {
        if (mode == Mode.BANGLA_FIXED || mode == Mode.BANGLA_PHONETIC) return "bn-BD";
        return "en-US";
    }

    private void rewriteTextBeforeCursor() {
        clearPhoneticBuffer();
        String apiKey = NeuroNovaPrefs.getOpenAiApiKey(this);
        if (apiKey.isEmpty()) {
            setStatus("Add OpenAI API key in ⚙ settings first");
            openSettings();
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence before = ic.getTextBeforeCursor(600, 0);
        if (before == null || before.toString().trim().length() < 2) {
            setStatus("Long press AI after typing a broken sentence");
            return;
        }
        String segment = extractLastSentenceSegment(before.toString());
        if (segment.trim().length() < 2) {
            setStatus("No sentence found before cursor");
            return;
        }
        setStatus("ChatGPT is rewriting typed text...");
        rewriteWithOpenAI(segment, segment.length());
    }

    private String extractLastSentenceSegment(String text) {
        String trimmedRight = rtrim(text);
        int start = 0;
        for (int i = trimmedRight.length() - 1; i >= 0; i--) {
            char c = trimmedRight.charAt(i);
            if (c == '\n' || c == '.' || c == '?' || c == '!' || c == '।') {
                start = i + 1;
                break;
            }
        }
        return trimmedRight.substring(start);
    }

    private String rtrim(String value) {
        int end = value.length();
        while (end > 0 && Character.isWhitespace(value.charAt(end - 1))) end--;
        return value.substring(0, end);
    }

    private void rewriteWithOpenAI(String userText, int replaceCharactersBeforeCursor) {
        new Thread(() -> {
            try {
                String output = callOpenAI(userText);
                output = cleanOutput(output);
                String finalOutput = output;
                mainHandler.post(() -> {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic == null) return;
                    if (replaceCharactersBeforeCursor > 0) ic.deleteSurroundingText(replaceCharactersBeforeCursor, 0);
                    String suffix = NeuroNovaPrefs.isAutoSpaceEnabled(this) ? " " : "";
                    ic.commitText(finalOutput + suffix, 1);
                    setStatus("AI sentence inserted");
                    playAiDoneSound();
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null && replaceCharactersBeforeCursor == 0) ic.commitText(userText + " ", 1);
                    setStatus("AI failed. Check internet/OpenAI API key.");
                    playAiErrorSound();
                    Toast.makeText(this, "NeuroNova ChatGPT error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private String callOpenAI(String userText) throws Exception {
        String apiKey = NeuroNovaPrefs.getOpenAiApiKey(this);
        String endpoint = "https://api.openai.com/v1/responses";
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(45000);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setDoOutput(true);

        JSONObject body = new JSONObject();
        body.put("model", NeuroNovaPrefs.getOpenAiModel(this));
        body.put("instructions", buildDeveloperInstructions());
        body.put("input", buildPrompt(userText));
        body.put("temperature", 0.2);
        body.put("max_output_tokens", 220);

        OutputStream os = conn.getOutputStream();
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8));
        writer.write(body.toString());
        writer.flush();
        writer.close();
        os.close();

        int code = conn.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code < 200 || code >= 300) throw new Exception("OpenAI HTTP " + code);

        JSONObject response = new JSONObject(sb.toString());
        String direct = response.optString("output_text", "");
        if (!direct.isEmpty()) return direct;

        JSONArray output = response.optJSONArray("output");
        if (output != null) {
            for (int i = 0; i < output.length(); i++) {
                JSONObject item = output.optJSONObject(i);
                if (item == null) continue;
                JSONArray content = item.optJSONArray("content");
                if (content == null) continue;
                for (int j = 0; j < content.length(); j++) {
                    JSONObject c = content.optJSONObject(j);
                    if (c == null) continue;
                    String text = c.optString("text", "");
                    if (!text.isEmpty()) return text;
                }
            }
        }

        throw new Exception("Empty OpenAI response");
    }

    private String buildDeveloperInstructions() {
        return "You are the AI writing assistant inside NeuroNova Keyboard by NeuroNova Tech. " +
                "You rewrite unfinished, broken, unclear, or grammatically incorrect text into complete natural text. " +
                "Keep the original meaning, do not add unnecessary new facts, and return only the final sentence or short paragraph.";
    }

    private String buildPrompt(String userText) {
        String languageHint = (mode == Mode.BANGLA_FIXED || mode == Mode.BANGLA_PHONETIC) ? "Bangla" : "English";
        String tone = NeuroNovaPrefs.getAiTone(this);
        return "Task: Rewrite the user text into a complete, natural, constructive sentence.\n\n" +
                "Rules:\n" +
                "- Keep the original meaning.\n" +
                "- Do not add unnecessary new facts.\n" +
                "- Correct grammar, spelling, punctuation, and flow.\n" +
                "- If the input is Bangla, output Bangla. If English, output English. If mixed, choose the dominant language.\n" +
                "- Preferred language hint: " + languageHint + ".\n" +
                "- Tone: " + tone + ".\n" +
                "- Return only the final sentence or short paragraph. No title, quotes, bullets, or explanation.\n\n" +
                "User text:\n" + userText;
    }

    private String cleanOutput(String text) {
        if (text == null) return "";
        String cleaned = text.trim();
        if ((cleaned.startsWith("\"") && cleaned.endsWith("\"")) || (cleaned.startsWith("“") && cleaned.endsWith("”"))) {
            cleaned = cleaned.substring(1, cleaned.length() - 1).trim();
        }
        return cleaned.replace("\n", " ").trim();
    }

    private void destroySpeechRecognizer() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
    }

    private void setStatus(String message) {
        mainHandler.post(() -> {
            if (statusView != null) statusView.setText(message);
        });
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
