package com.neuronovatech.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

public final class NeuroNovaPrefs {
    private static final String PREF_NAME = "neuronova_keyboard_prefs";
    private static final String KEY_OPENAI_API_KEY = "openai_api_key";
    private static final String KEY_OPENAI_MODEL = "openai_model";
    private static final String KEY_AI_TONE = "ai_tone";
    private static final String KEY_VIBRATION = "vibration_enabled";
    private static final String KEY_AUTO_SPACE = "auto_space_enabled";
    private static final String KEY_AI_SOUND = "ai_sound_enabled";
    private static final String KEY_KEYBOARD_SIZE = "keyboard_size";
    private static final String KEY_THEME = "keyboard_theme";
    private static final String KEY_BACKGROUND_IMAGE_URI = "background_image_uri";
    private static final String KEY_DEFAULT_LAYOUT = "default_layout";
    private static final String KEY_SHOW_SUGGESTIONS = "show_suggestions";

    private NeuroNovaPrefs() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static String getOpenAiApiKey(Context context) {
        String saved = prefs(context).getString(KEY_OPENAI_API_KEY, "");
        if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        return BuildConfig.DEFAULT_OPENAI_API_KEY == null ? "" : BuildConfig.DEFAULT_OPENAI_API_KEY.trim();
    }

    public static void setOpenAiApiKey(Context context, String value) {
        prefs(context).edit().putString(KEY_OPENAI_API_KEY, value == null ? "" : value.trim()).apply();
    }

    public static String getOpenAiModel(Context context) {
        String saved = prefs(context).getString(KEY_OPENAI_MODEL, "");
        if (saved != null && !saved.trim().isEmpty()) return saved.trim();
        return BuildConfig.DEFAULT_OPENAI_MODEL == null || BuildConfig.DEFAULT_OPENAI_MODEL.trim().isEmpty()
                ? "gpt-4.1-mini" : BuildConfig.DEFAULT_OPENAI_MODEL.trim();
    }

    public static void setOpenAiModel(Context context, String value) {
        prefs(context).edit().putString(KEY_OPENAI_MODEL, value == null ? "" : value.trim()).apply();
    }

    public static String getAiTone(Context context) {
        return prefs(context).getString(KEY_AI_TONE, "Clear and polite");
    }

    public static void setAiTone(Context context, String value) {
        prefs(context).edit().putString(KEY_AI_TONE, value).apply();
    }

    public static boolean isVibrationEnabled(Context context) {
        return prefs(context).getBoolean(KEY_VIBRATION, true);
    }

    public static void setVibrationEnabled(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_VIBRATION, value).apply();
    }

    public static boolean isAutoSpaceEnabled(Context context) {
        return prefs(context).getBoolean(KEY_AUTO_SPACE, true);
    }

    public static void setAutoSpaceEnabled(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_AUTO_SPACE, value).apply();
    }

    public static boolean isAiSoundEnabled(Context context) {
        return prefs(context).getBoolean(KEY_AI_SOUND, true);
    }

    public static void setAiSoundEnabled(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_AI_SOUND, value).apply();
    }

    public static String getKeyboardSize(Context context) {
        return prefs(context).getString(KEY_KEYBOARD_SIZE, "Medium");
    }

    public static void setKeyboardSize(Context context, String value) {
        prefs(context).edit().putString(KEY_KEYBOARD_SIZE, value).apply();
    }

    public static String getTheme(Context context) {
        return prefs(context).getString(KEY_THEME, "NeuroNova Blue");
    }

    public static void setTheme(Context context, String value) {
        prefs(context).edit().putString(KEY_THEME, value).apply();
    }

    public static String getBackgroundImageUri(Context context) {
        return prefs(context).getString(KEY_BACKGROUND_IMAGE_URI, "");
    }

    public static void setBackgroundImageUri(Context context, String value) {
        prefs(context).edit().putString(KEY_BACKGROUND_IMAGE_URI, value == null ? "" : value).apply();
    }

    public static String getDefaultLayout(Context context) {
        return prefs(context).getString(KEY_DEFAULT_LAYOUT, "English");
    }

    public static void setDefaultLayout(Context context, String value) {
        prefs(context).edit().putString(KEY_DEFAULT_LAYOUT, value).apply();
    }

    public static boolean showSuggestions(Context context) {
        return prefs(context).getBoolean(KEY_SHOW_SUGGESTIONS, true);
    }

    public static void setShowSuggestions(Context context, boolean value) {
        prefs(context).edit().putBoolean(KEY_SHOW_SUGGESTIONS, value).apply();
    }
}
