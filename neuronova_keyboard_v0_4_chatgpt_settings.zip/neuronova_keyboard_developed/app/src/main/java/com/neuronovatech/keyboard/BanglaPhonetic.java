package com.neuronovatech.keyboard;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Original NeuroNova Bangla phonetic engine.
 * This is an Avro-style phonetic mode created from scratch for this project.
 * It does not copy Ridmik or Avro source code.
 */
public final class BanglaPhonetic {
    private BanglaPhonetic() {}

    private static final Map<String, String> COMMON_WORDS = new LinkedHashMap<>();
    private static final Map<String, String> CONSONANTS = new LinkedHashMap<>();
    private static final Map<String, String> INDEPENDENT_VOWELS = new LinkedHashMap<>();
    private static final Map<String, String> VOWEL_SIGNS = new LinkedHashMap<>();

    static {
        // High-value Bangla phonetic dictionary for natural daily typing.
        putWords(
                "ami", "আমি", "amra", "আমরা", "amar", "আমার", "amake", "আমাকে", "amader", "আমাদের",
                "tumi", "তুমি", "tomar", "তোমার", "tomake", "তোমাকে", "tomader", "তোমাদের",
                "apni", "আপনি", "apnar", "আপনার", "apnake", "আপনাকে", "apnader", "আপনাদের",
                "se", "সে", "tar", "তার", "take", "তাকে", "tara", "তারা", "tader", "তাদের",
                "ei", "এই", "eta", "এটা", "eita", "এইটা", "ekhane", "এখানে", "ekhon", "এখন", "ekta", "একটা",
                "oi", "ওই", "ota", "ওটা", "oita", "ওইটা", "okhane", "ওখানে", "tokhon", "তখন",
                "ki", "কি", "kivabe", "কিভাবে", "keno", "কেন", "kothay", "কোথায়", "kotha", "কথা", "kokhon", "কখন",
                "ke", "কে", "kar", "কার", "kake", "কাকে", "kichu", "কিছু", "kintu", "কিন্তু", "tai", "তাই",
                "hobe", "হবে", "hoy", "হয়", "hocche", "হচ্ছে", "hochche", "হচ্ছে", "holo", "হলো", "korbo", "করবো",
                "kori", "করি", "kore", "করে", "kora", "করা", "korar", "করার", "korben", "করবেন", "korte", "করতে",
                "bolbo", "বলবো", "bole", "বলে", "bola", "বলা", "bolen", "বলেন", "bolte", "বলতে",
                "jabo", "যাবো", "jai", "যাই", "jabe", "যাবে", "jete", "যেতে", "jawar", "যাওয়ার", "asche", "আসছে",
                "aschi", "আসছি", "ashbo", "আসবো", "ase", "আছে", "ache", "আছে", "nai", "নাই", "nei", "নেই",
                "valo", "ভালো", "bhalo", "ভালো", "khub", "খুব", "beshi", "বেশি", "kom", "কম", "onek", "অনেক",
                "aj", "আজ", "ajke", "আজকে", "kal", "কাল", "agami", "আগামী", "gotokal", "গতকাল", "prottek", "প্রত্যেক",
                "dhonnobad", "ধন্যবাদ", "sorry", "সরি", "please", "প্লিজ", "sir", "স্যার", "madam", "ম্যাডাম", "vai", "ভাই",
                "bon", "বোন", "ma", "মা", "baba", "বাবা", "bondhu", "বন্ধু", "manush", "মানুষ", "jonno", "জন্য",
                "bangla", "বাংলা", "bangladesh", "বাংলাদেশ", "dhaka", "ঢাকা", "chittagong", "চট্টগ্রাম", "ctg", "চট্টগ্রাম",
                "school", "স্কুল", "college", "কলেজ", "university", "ইউনিভার্সিটি", "class", "ক্লাস", "exam", "এক্সাম", "quiz", "কুইজ",
                "result", "রেজাল্ট", "final", "ফাইনাল", "makeup", "মেকআপ", "marks", "মার্কস", "number", "নম্বর",
                "facebook", "ফেসবুক", "youtube", "ইউটিউব", "whatsapp", "হোয়াটসঅ্যাপ", "messenger", "মেসেঞ্জার", "email", "ইমেইল",
                "office", "অফিস", "meeting", "মিটিং", "project", "প্রজেক্ট", "client", "ক্লায়েন্ট", "team", "টিম",
                "allah", "আল্লাহ", "inshaallah", "ইনশাআল্লাহ", "assalamu", "আসসালামু", "alaikum", "আলাইকুম"
        );

        // Longest tokens first.
        CONSONANTS.put("ksh", "ক্ষ");
        CONSONANTS.put("kkh", "ক্ষ");
        CONSONANTS.put("ng", "ং");
        CONSONANTS.put("ny", "ঞ");
        CONSONANTS.put("kh", "খ");
        CONSONANTS.put("gh", "ঘ");
        CONSONANTS.put("chh", "ছ");
        CONSONANTS.put("ch", "চ");
        CONSONANTS.put("jh", "ঝ");
        CONSONANTS.put("th", "থ");
        CONSONANTS.put("dh", "ধ");
        CONSONANTS.put("ph", "ফ");
        CONSONANTS.put("bh", "ভ");
        CONSONANTS.put("sh", "শ");
        CONSONANTS.put("ss", "ষ");
        CONSONANTS.put("rr", "ড়");
        CONSONANTS.put("rh", "ঢ়");
        CONSONANTS.put("gn", "জ্ঞ");
        CONSONANTS.put("gg", "জ্ঞ");
        CONSONANTS.put("tr", "ত্র");
        CONSONANTS.put("kr", "ক্র");
        CONSONANTS.put("gr", "গ্র");
        CONSONANTS.put("pr", "প্র");
        CONSONANTS.put("br", "ব্র");
        CONSONANTS.put("dr", "দ্র");
        CONSONANTS.put("fr", "ফ্র");
        CONSONANTS.put("sk", "স্ক");
        CONSONANTS.put("st", "স্ট");
        CONSONANTS.put("sp", "স্প");
        CONSONANTS.put("k", "ক");
        CONSONANTS.put("g", "গ");
        CONSONANTS.put("c", "ক");
        CONSONANTS.put("j", "জ");
        CONSONANTS.put("z", "জ");
        CONSONANTS.put("t", "ত");
        CONSONANTS.put("d", "দ");
        CONSONANTS.put("n", "ন");
        CONSONANTS.put("p", "প");
        CONSONANTS.put("f", "ফ");
        CONSONANTS.put("b", "ব");
        CONSONANTS.put("v", "ভ");
        CONSONANTS.put("m", "ম");
        CONSONANTS.put("y", "য়");
        CONSONANTS.put("r", "র");
        CONSONANTS.put("l", "ল");
        CONSONANTS.put("s", "স");
        CONSONANTS.put("h", "হ");
        CONSONANTS.put("w", "ও");
        CONSONANTS.put("x", "ক্স");
        CONSONANTS.put("q", "ক");

        INDEPENDENT_VOWELS.put("ou", "ঔ");
        INDEPENDENT_VOWELS.put("oi", "ঐ");
        INDEPENDENT_VOWELS.put("aa", "আ");
        INDEPENDENT_VOWELS.put("ee", "ঈ");
        INDEPENDENT_VOWELS.put("ii", "ঈ");
        INDEPENDENT_VOWELS.put("oo", "ঊ");
        INDEPENDENT_VOWELS.put("uu", "ঊ");
        INDEPENDENT_VOWELS.put("a", "আ");
        INDEPENDENT_VOWELS.put("i", "ই");
        INDEPENDENT_VOWELS.put("u", "উ");
        INDEPENDENT_VOWELS.put("e", "এ");
        INDEPENDENT_VOWELS.put("o", "ও");

        VOWEL_SIGNS.put("ou", "ৌ");
        VOWEL_SIGNS.put("oi", "ৈ");
        VOWEL_SIGNS.put("aa", "া");
        VOWEL_SIGNS.put("ee", "ী");
        VOWEL_SIGNS.put("ii", "ী");
        VOWEL_SIGNS.put("oo", "ূ");
        VOWEL_SIGNS.put("uu", "ূ");
        VOWEL_SIGNS.put("a", "া");
        VOWEL_SIGNS.put("i", "ি");
        VOWEL_SIGNS.put("u", "ু");
        VOWEL_SIGNS.put("e", "ে");
        VOWEL_SIGNS.put("o", "ো");
    }

    private static void putWords(String... pairs) {
        for (int i = 0; i + 1 < pairs.length; i += 2) COMMON_WORDS.put(pairs[i], pairs[i + 1]);
    }

    public static String transliterate(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        StringBuilder token = new StringBuilder();
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                token.append(c);
            } else {
                flushToken(token, out);
                if (Character.isDigit(c)) out.append(toBanglaDigit(c));
                else out.append(c);
            }
        }
        flushToken(token, out);
        return fixCommonOutputs(out.toString());
    }

    public static List<String> suggestions(String raw) {
        ArrayList<String> results = new ArrayList<>();
        if (raw == null) return results;
        String clean = raw.toLowerCase(Locale.US).trim();
        if (clean.length() == 0) return results;

        String exact = COMMON_WORDS.get(clean);
        if (exact != null) addUnique(results, exact);
        String converted = transliterate(clean);
        addUnique(results, converted);

        for (Map.Entry<String, String> entry : COMMON_WORDS.entrySet()) {
            if (entry.getKey().startsWith(clean) && results.size() < 4) addUnique(results, entry.getValue());
        }
        return results;
    }

    private static void addUnique(List<String> list, String value) {
        if (value == null || value.length() == 0) return;
        if (!list.contains(value)) list.add(value);
    }

    private static void flushToken(StringBuilder token, StringBuilder out) {
        if (token.length() == 0) return;
        String value = token.toString();
        String lower = value.toLowerCase(Locale.US);
        String common = COMMON_WORDS.get(lower);
        if (common != null) out.append(common);
        else out.append(transliterateSimple(lower));
        token.setLength(0);
    }

    private static String transliterateSimple(String input) {
        StringBuilder out = new StringBuilder();
        int i = 0;
        while (i < input.length()) {
            char current = input.charAt(i);
            if (Character.isDigit(current)) {
                out.append(toBanglaDigit(current));
                i++;
                continue;
            }
            if (!Character.isLetter(current)) {
                out.append(current);
                i++;
                continue;
            }

            Match consonant = match(CONSONANTS, input, i);
            if (consonant != null) {
                out.append(consonant.value);
                i += consonant.token.length();
                Match vowel = match(VOWEL_SIGNS, input, i);
                if (vowel != null) {
                    // A single 'o' is often the inherent vowel in Bangla words. Keep it implicit unless doubled.
                    if (!("o".equals(vowel.token) && shouldKeepImplicitO(input, i))) {
                        out.append(vowel.value);
                    }
                    i += vowel.token.length();
                }
                continue;
            }

            Match vowel = match(INDEPENDENT_VOWELS, input, i);
            if (vowel != null) {
                out.append(vowel.value);
                i += vowel.token.length();
                continue;
            }

            out.append(current);
            i++;
        }
        return out.toString();
    }

    private static boolean shouldKeepImplicitO(String input, int vowelPosition) {
        // Examples: mon -> মন, kolom -> কলম. If user wants ও, they can type oo.
        return vowelPosition + 1 < input.length();
    }

    private static String fixCommonOutputs(String text) {
        return text
                .replace("স্কহুল", "স্কুল")
                .replace("কোলোজ", "কলেজ")
                .replace("বাংলা", "বাংলা")
                .replace("বাংলাদেশ", "বাংলাদেশ")
                .replace("আল্লাহ", "আল্লাহ");
    }

    private static String toBanglaDigit(char c) {
        switch (c) {
            case '0': return "০";
            case '1': return "১";
            case '2': return "২";
            case '3': return "৩";
            case '4': return "৪";
            case '5': return "৫";
            case '6': return "৬";
            case '7': return "৭";
            case '8': return "৮";
            case '9': return "৯";
            default: return String.valueOf(c);
        }
    }

    private static Match match(Map<String, String> map, String input, int pos) {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String token = entry.getKey();
            if (pos + token.length() <= input.length() && input.startsWith(token, pos)) {
                return new Match(token, entry.getValue());
            }
        }
        return null;
    }

    private static class Match {
        final String token;
        final String value;
        Match(String token, String value) { this.token = token; this.value = value; }
    }
}
