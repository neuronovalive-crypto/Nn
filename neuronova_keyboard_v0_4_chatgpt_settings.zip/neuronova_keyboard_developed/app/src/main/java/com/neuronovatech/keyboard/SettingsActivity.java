package com.neuronovatech.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private static final int PICK_BACKGROUND_IMAGE = 301;

    private EditText apiKeyInput;
    private EditText modelInput;
    private Spinner toneSpinner;
    private Spinner sizeSpinner;
    private Spinner themeSpinner;
    private Spinner layoutSpinner;
    private CheckBox vibrationCheck;
    private CheckBox autoSpaceCheck;
    private CheckBox aiSoundCheck;
    private CheckBox suggestionsCheck;
    private TextView backgroundStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(20));
        scroll.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("neuronova_logo", "drawable", getPackageName()));
        logo.setAdjustViewBounds(true);
        root.addView(logo, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(100)));

        TextView title = new TextView(this);
        title.setText("NeuroNova Keyboard Settings");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(14), 0, dp(12));
        root.addView(title);

        TextView aiInfo = new TextView(this);
        aiInfo.setText("ChatGPT/OpenAI AI button is enabled through the OpenAI Responses API. The app uses your saved key first, otherwise it uses the default build key from GitHub Secrets/local Gradle property. For public release, a secure backend is safer than shipping a key inside the APK.");
        aiInfo.setTextSize(14);
        aiInfo.setPadding(0, 0, 0, dp(10));
        root.addView(aiInfo);

        apiKeyInput = new EditText(this);
        apiKeyInput.setHint("OpenAI API Key — changeable");
        apiKeyInput.setSingleLine(true);
        apiKeyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        apiKeyInput.setText(NeuroNovaPrefs.getOpenAiApiKey(this));
        root.addView(apiKeyInput, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));

        modelInput = new EditText(this);
        modelInput.setHint("OpenAI model, e.g. gpt-4.1-mini");
        modelInput.setSingleLine(true);
        modelInput.setInputType(InputType.TYPE_CLASS_TEXT);
        modelInput.setText(NeuroNovaPrefs.getOpenAiModel(this));
        root.addView(modelInput, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)));

        toneSpinner = spinner(root, "AI writing tone", new String[]{"Clear and polite", "Professional", "Short and simple", "Friendly", "Formal Bangla/English"}, NeuroNovaPrefs.getAiTone(this));
        sizeSpinner = spinner(root, "Keyboard size", new String[]{"Small", "Medium", "Large", "Extra Large"}, NeuroNovaPrefs.getKeyboardSize(this));
        themeSpinner = spinner(root, "Keyboard colour theme", new String[]{"NeuroNova Blue", "Dark Black", "Light White", "Green", "Purple"}, NeuroNovaPrefs.getTheme(this));
        layoutSpinner = spinner(root, "Default keyboard layout", new String[]{"English", "Bangla Fixed", "Avro Phonetic"}, NeuroNovaPrefs.getDefaultLayout(this));

        vibrationCheck = new CheckBox(this);
        vibrationCheck.setText("Keyboard vibration feedback");
        vibrationCheck.setChecked(NeuroNovaPrefs.isVibrationEnabled(this));
        root.addView(vibrationCheck);

        autoSpaceCheck = new CheckBox(this);
        autoSpaceCheck.setText("Add space after AI output");
        autoSpaceCheck.setChecked(NeuroNovaPrefs.isAutoSpaceEnabled(this));
        root.addView(autoSpaceCheck);

        aiSoundCheck = new CheckBox(this);
        aiSoundCheck.setText("AI button start/end sound");
        aiSoundCheck.setChecked(NeuroNovaPrefs.isAiSoundEnabled(this));
        root.addView(aiSoundCheck);

        suggestionsCheck = new CheckBox(this);
        suggestionsCheck.setText("Show Avro-style phonetic suggestions");
        suggestionsCheck.setChecked(NeuroNovaPrefs.showSuggestions(this));
        root.addView(suggestionsCheck);

        backgroundStatus = new TextView(this);
        backgroundStatus.setText(backgroundLabel());
        backgroundStatus.setTextSize(14);
        backgroundStatus.setPadding(0, dp(14), 0, dp(6));
        root.addView(backgroundStatus);

        Button chooseBg = new Button(this);
        chooseBg.setText("Choose keyboard background image");
        chooseBg.setAllCaps(false);
        chooseBg.setOnClickListener(v -> chooseBackgroundImage());
        root.addView(chooseBg, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        Button clearBg = new Button(this);
        clearBg.setText("Remove background image");
        clearBg.setAllCaps(false);
        clearBg.setOnClickListener(v -> {
            NeuroNovaPrefs.setBackgroundImageUri(this, "");
            backgroundStatus.setText(backgroundLabel());
            Toast.makeText(this, "Background image removed", Toast.LENGTH_SHORT).show();
        });
        root.addView(clearBg, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        Button save = new Button(this);
        save.setText("Save Settings");
        save.setAllCaps(false);
        save.setTextSize(17);
        save.setOnClickListener(v -> saveSettings());
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        saveLp.setMargins(0, dp(16), 0, 0);
        root.addView(save, saveLp);

        TextView help = new TextView(this);
        help.setText("How to use AI button:\n\n• Tap AI: speak a broken or unfinished sentence.\n• Long press AI: rewrite the sentence already typed before the cursor.\n• AI start sound plays when AI begins. Done sound plays after response is inserted.\n\nKeyboard layouts included:\n• English QWERTY\n• Bangla fixed\n• Avro-style Bangla phonetic\n• Symbols\n• Emoji\n\nPrivacy: normal typing is not sent to AI. Only text used by the AI button goes to OpenAI.");
        help.setTextSize(14);
        help.setPadding(0, dp(18), 0, dp(20));
        root.addView(help);

        setContentView(scroll);
    }

    private Spinner spinner(LinearLayout root, String labelText, String[] values, String current) {
        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextSize(15);
        label.setPadding(0, dp(16), 0, dp(6));
        root.addView(label);

        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
        spinner.setAdapter(adapter);
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) spinner.setSelection(i);
        }
        root.addView(spinner, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));
        return spinner;
    }

    private void chooseBackgroundImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_BACKGROUND_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_BACKGROUND_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            final int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) { }
            NeuroNovaPrefs.setBackgroundImageUri(this, uri.toString());
            if (backgroundStatus != null) backgroundStatus.setText(backgroundLabel());
            Toast.makeText(this, "Background image saved", Toast.LENGTH_SHORT).show();
        }
    }

    private String backgroundLabel() {
        String uri = NeuroNovaPrefs.getBackgroundImageUri(this);
        return uri == null || uri.isEmpty() ? "Background image: none" : "Background image: selected";
    }

    private void saveSettings() {
        NeuroNovaPrefs.setOpenAiApiKey(this, apiKeyInput.getText().toString());
        NeuroNovaPrefs.setOpenAiModel(this, modelInput.getText().toString());
        NeuroNovaPrefs.setAiTone(this, toneSpinner.getSelectedItem().toString());
        NeuroNovaPrefs.setKeyboardSize(this, sizeSpinner.getSelectedItem().toString());
        NeuroNovaPrefs.setTheme(this, themeSpinner.getSelectedItem().toString());
        NeuroNovaPrefs.setDefaultLayout(this, layoutSpinner.getSelectedItem().toString());
        NeuroNovaPrefs.setVibrationEnabled(this, vibrationCheck.isChecked());
        NeuroNovaPrefs.setAutoSpaceEnabled(this, autoSpaceCheck.isChecked());
        NeuroNovaPrefs.setAiSoundEnabled(this, aiSoundCheck.isChecked());
        NeuroNovaPrefs.setShowSuggestions(this, suggestionsCheck.isChecked());
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
