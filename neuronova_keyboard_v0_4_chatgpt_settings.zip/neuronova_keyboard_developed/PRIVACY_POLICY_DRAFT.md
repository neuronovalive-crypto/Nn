# NeuroNova Keyboard Privacy Policy Draft

NeuroNova Keyboard is developed by NeuroNova Tech.

## Normal typing
NeuroNova Keyboard does not send normal keystrokes to any server.

## AI Button
When the user taps or long-presses the AI button, the selected spoken or typed text is sent to OpenAI/ChatGPT engine for rewriting/completion.

## Microphone
Microphone permission is used only when the user taps the AI button for speech input.

## API key
This MVP can store an OpenAI API key in private app preferences on the device and can also use a default build key set through GitHub Secrets/local Gradle property. For a public production release, NeuroNova Tech should use secure server-side key management.

## Personalization
Keyboard size, colour theme, layout choice, sound, vibration, and background image preference are stored only on the user device.

## Data retention
This MVP does not store AI prompts or outputs after insertion.

## Thanks
Thanks to developers: M HOSSAIN and R ISLAM RAHI.

## Contact
NeuroNova Tech
