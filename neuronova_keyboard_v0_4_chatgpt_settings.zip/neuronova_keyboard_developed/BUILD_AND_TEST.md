# NeuroNova Keyboard Build and Test Guide

## Build in Android Studio
1. Open Android Studio.
2. Open this project folder.
3. Wait for Gradle sync.
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Install `app/build/outputs/apk/debug/app-debug.apk` on your Android phone.

## Build with OpenAI default key locally
Create or edit `~/.gradle/gradle.properties` or run Gradle with properties:

```bash
gradle assembleDebug -POPENAI_API_KEY="YOUR_KEY" -POPENAI_MODEL="gpt-4.1-mini"
```

The app can also store/change the API key from the in-app Settings page.

## Enable keyboard on phone
1. Open NeuroNova Keyboard app.
2. Tap **Enable NeuroNova Keyboard**.
3. Turn on NeuroNova Keyboard.
4. Tap **Choose Keyboard** and select NeuroNova Keyboard.

## Test AI button
- Tap AI: speak an unfinished sentence.
- Long press AI: rewrite the text before cursor.
- Start sound plays when AI begins.
- Done sound plays after AI result is inserted.

## Test personalization
Open Settings and test:
- OpenAI API key
- OpenAI model
- Keyboard size
- Colour theme
- Default layout
- Background image
- Sound, vibration, and suggestions

## Important
For public Play Store release, do not rely on a hardcoded API key inside the APK. Use a secure backend/proxy with billing limits and abuse protection.
