# NeuroNova Keyboard

Original Android keyboard project for NeuroNova Tech.

## What is included

- English QWERTY keyboard
- Bangla fixed keyboard
- Avro-style Bangla phonetic mode: `ami → আমি`
- Bangla phonetic suggestion strip
- Symbols and emoji layouts
- ChatGPT/OpenAI AI button
- Tap AI: speak an unfinished sentence and insert a completed sentence
- Long press AI: rewrite the sentence before cursor
- AI start sound and AI done sound
- Keyboard size setting
- Keyboard colour theme setting
- Default layout setting
- Keyboard background image setting
- Vibration and auto-space settings
- Privacy policy screen
- GitHub Actions APK build workflow

## AI engine

The AI button uses OpenAI's Responses API endpoint from the app's Java code.

The app checks API key in this order:

1. API key saved in app Settings
2. Default build key from Gradle property / GitHub Secret
3. If no key exists, Settings opens automatically

## GitHub default API key setup

Do not hardcode your API key in public files. Use GitHub Secrets:

- Secret name: `OPENAI_API_KEY`
- Optional repository variable: `OPENAI_MODEL`

Then run the GitHub Actions workflow.

## Privacy behavior

Normal keyboard typing stays on device. Only these actions send text to OpenAI:

- Tap AI after speech recognition
- Long press AI to rewrite typed text before cursor

## Important legal note

This project is an original NeuroNova Keyboard app. Do not copy Ridmik Keyboard source code, private assets, exact UI, or protected branding. You can build similar useful features using original code and design.
