# Play Store Listing Draft

## App name
NeuroNova Keyboard

## Short description
Bangla and English keyboard with ChatGPT/OpenAI AI sentence completion.

## Full description
NeuroNova Keyboard is a Bangla and English keyboard from NeuroNova Tech. It includes English QWERTY, Bangla fixed typing, Avro-style Bangla phonetic typing, emoji, symbols, custom size, colour themes, background image support, and an AI button.

The AI button helps users complete unfinished or broken sentences. Tap AI to speak a sentence, or long press AI to rewrite the text before the cursor.

Normal typing stays on the device. Only text used with the AI button is sent to OpenAI for completion or correction.

## Keywords
Bangla keyboard, English keyboard, AI keyboard, Bengali keyboard, Avro-style keyboard, ChatGPT/OpenAI AI, NeuroNova Tech
