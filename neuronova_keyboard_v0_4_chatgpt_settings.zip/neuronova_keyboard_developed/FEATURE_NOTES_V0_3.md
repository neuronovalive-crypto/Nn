# NeuroNova Keyboard v0.3 Feature Notes

This update improves the MVP with an original Avro-style Bangla phonetic mode and a more polished NeuroNova keyboard look.

## Added / improved

- Avro-style Bangla phonetic button shown as `AVRO`.
- Larger phonetic word dictionary for daily Bangla typing.
- Suggestion strip for phonetic typing.
- Tap suggestion strip to accept the top suggestion.
- Improved Bangla fixed layout remains available as `কখ`.
- English, symbols, emoji, AI button, speech-to-AI, and long-press AI rewrite remain available.
- Better key shape, panel styling, and NeuroNova dark-blue theme.

## Important legal note

This project does not copy Ridmik Keyboard or Avro source code, assets, layouts, database, or branding. It is an original NeuroNova Tech keyboard project with familiar keyboard categories.

## Still not complete like a mature keyboard

To reach a production-level keyboard, these modules still need major development:

- Full predictive dictionary
- Smart autocorrect
- Full emoji/sticker/GIF panel
- Clipboard manager
- Full theme store
- Personal dictionary
- Gesture/swipe typing
- Import/export settings
- Better tablets/landscape layouts
- Play Store signed release build
