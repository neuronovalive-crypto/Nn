# NeuroNova Keyboard v0.4 Feature Notes

Added in v0.4:

- Switched AI engine from Gemini to ChatGPT/OpenAI Responses API.
- Default OpenAI API key support through GitHub Secret or local Gradle property.
- API key remains changeable inside app settings.
- OpenAI model is changeable in settings.
- Keyboard size settings: Small, Medium, Large, Extra Large.
- Colour themes: NeuroNova Blue, Dark Black, Light White, Green, Purple.
- Default layout setting: English, Bangla Fixed, Avro Phonetic.
- Background image picker for keyboard.
- AI start sound when pressing AI.
- AI done sound when response is inserted.
- AI error sound if API/speech fails.
- Privacy policy updated with thanks to developers M HOSSAIN and R ISLAM RAHI.

Important legal/product note:
This app uses original NeuroNova code and layout logic. It should not copy Ridmik source code, private assets, or exact copyrighted design.
