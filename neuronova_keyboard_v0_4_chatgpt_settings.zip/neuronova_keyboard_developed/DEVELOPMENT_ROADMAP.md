# NeuroNova Keyboard Roadmap

## Completed in this MVP

- Original app identity and package
- Basic custom keyboard service
- English keyboard layout
- Bangla fixed keyboard layout
- Bangla phonetic keyboard layout
- Symbol page
- Emoji page
- AI button
- Speech-to-AI-to-text insertion
- Typed sentence rewrite through AI
- Settings page
- Privacy screen

## Next development phase

### Phase 1: Keyboard typing quality

- Add full Bangla phonetic rules
- Add Bangla word dictionary
- Add candidate suggestion strip
- Add autocorrect for English
- Add punctuation smart spacing

### Phase 2: AI feature polish

- AI popup result preview before insertion
- AI modes: correct, complete, formal, short, translate
- Bangla ↔ English translation button
- Local history toggle with user consent

### Phase 3: UI polish

- Better responsive layouts for different screen sizes
- Theme selection
- One-handed mode
- Better tablet layout
- Professional app icon set

### Phase 4: Production security

- Secure API gateway backend
- Rate limit per user/device
- Abuse protection
- Crash/error analytics with user consent
- Play Store privacy declaration

### Phase 5: Release

- Internal test build
- Closed beta
- Play Store production release
