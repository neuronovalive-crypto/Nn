# Build NeuroNova Keyboard APK with GitHub Actions

## 1. Upload the project
Upload all project files to a GitHub repository.

## 2. Add OpenAI API key safely
Do **not** paste your OpenAI API key into public source files.

Use GitHub Secrets:

1. Repository → Settings
2. Secrets and variables → Actions
3. New repository secret
4. Name: `OPENAI_API_KEY`
5. Value: your OpenAI API key
6. Save

Optional model variable:

1. Repository → Settings
2. Secrets and variables → Actions → Variables
3. New repository variable
4. Name: `OPENAI_MODEL`
5. Value: `gpt-4.1-mini` or another OpenAI model you can use

## 3. Build APK
1. Go to Actions
2. Open **Build NeuroNova Keyboard APK**
3. Tap **Run workflow**
4. Wait until the build completes
5. Download artifact: **NeuroNova-Keyboard-debug-apk**

## Notes
- The APK will have a default OpenAI key only if the GitHub Secret is set.
- The app still lets you change the API key from Settings.
- For a public Play Store app, the safest method is a server-side API proxy, not a key inside the APK.
